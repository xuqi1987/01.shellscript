mkdir tmp
cd tmp
wget https://nodejs.org/dist/v8.9.1/node-v8.9.1.tar.gz
tar -xzvf node-v8.9.1.tar.gz

cd node*

