cd /var/www/html/
git clone git@github.com:ziahamza/webui-aria2.git

mv webui-aria2 d



