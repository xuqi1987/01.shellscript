sudo apt-get install aria2
aria2c -v | grep 'aria2 version'
