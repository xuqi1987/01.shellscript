gip sqdownb.onlinedown.net
gip get.docker.com
gip download.docker.com
gip raw.githubusercontent.com

wget -qO- https://get.docker.com/ | sh

docker pull sameersbn/redmine:latest
