# 21.script
many scripts for install software 
