if [ -n "`uname -a | grep x86`" ];then
	echo "hello"
else
	echo "xxx"
fi

